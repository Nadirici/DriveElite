<?php

$_SESSION["motdepasse"];
$_SESSION["date"] ;
$_SESSION["email"] ;
$_SESSION["nom"] ;
$_SESSION["prenom"] ;
$_SESSION["gender"] ;
$_SESSION["profession"];
$_SESSION["sujet"];
$_SESSION["textarea"] ;
$_SESSION['email_envoye'] ;
$_SESSION['panier'];
$_SESSION["pseudonyme"];
$_SESSION["page"];

//tableau de prosuits avec leur catégorie 
$_SESSION["produits"];


